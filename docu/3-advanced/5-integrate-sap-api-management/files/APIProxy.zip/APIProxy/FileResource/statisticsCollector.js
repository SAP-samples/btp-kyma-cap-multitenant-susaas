var pathSuffix = context.getVariable("proxy.pathsuffix");

if(pathSuffix) {
    // trim the forward slash
    if(pathSuffix.indexOf("/") == 0) {
        pathSuffix = pathSuffix.substring(1, pathSuffix.length);
    }
    if(pathSuffix.indexOf("(") > -1) {
        context.setVariable("odata.primaryEntity", pathSuffix.split("(")[0]);
    } else {
        context.setVariable("odata.list", pathSuffix);
    }
}
